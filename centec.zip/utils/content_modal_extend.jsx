export const CONTENT = [
    {
      title: "Registros del programa",
      description: programInfo && programInfo.recordsProgram,
    },
    {
      title: "Duración del programa",
      description: programInfo && programInfo.timeProgram,
    },
    {
      title: "Objetivos del programa",
      description: programInfo && programInfo.recordsProgram,
    },
    {
      title: "Perfil del egresado",
      description: programInfo && programInfo.recordsProgram,
    },
    {
      title: "Certificado de aptitud ocupacional a expedir",
      description: programInfo && programInfo.recordsProgram,
    },
  ];