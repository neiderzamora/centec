export const FORM_PAYU = [
    {
      name: "buyerFullName",
      type: "text",
      placeholder: "Nombre Completo",
    },
    {
      name: "buyerEmail",
      type: "email",
      placeholder: "Correo Electrónico",
    },
    {
      name: "mobilePhone",
      type: "text",
      placeholder: "Teléfono Móvil",
    },
    {
      name: "extra1",
      type: "text",
      placeholder: "Cédula",
    },
  ];
  