export const MERCHAND_ID = "1007567"
export const ACCOUNT_ID = "1016348"
export const API_KEY = "z58rjJlt3AT8IEvyluu6L51R9T"
export const CURRENCY = "COP"