export const LIST_CHARACTERISTIC = [
  {
    subsidiesCentec: [
      {
        name: "Dirigida a: Todos los estudiantes de los programas técnicos.",
      },
      {
        name: "Cubre: Hasta el 50% del valor de la matrícula",
      },
      {
        name: "Periodicidad: Préstamo por un semestre",
      },
    ],
  },
  {
    subsidiesBrothersTwo: [
      {
        name: "Primer hermano se le aplica 15% del valor de la matrícula",
      },
      {
        name: "Segundo hermano no se le aplica descuento",
      },
    ],
  },
  {
    subsidiesBrothersThree: [
      {
        name: "Primer hermano se le aplica 15% del valor de la matrícula",
      },
      {
        name: "Segundo hermano se le aplica 20% del valor de la matrícula",
      },
      {
        name: "Tercer hermano no se le aplica descuento",
      },
    ],
  },
];
