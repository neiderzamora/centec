/** @type {import('next').NextConfig} */
const nextConfig = {
       images: {
        domains: ["educentec.edu.co"],
        /* unoptimized: true, */
      }, 
      /* output: "export" */
    };
    
    module.exports = nextConfig;