"use client";

import { Fragment, useRef } from "react";
import { Dialog, Transition } from "@headlessui/react";
import { XMarkIcon } from "@heroicons/react/24/outline";
import { AcademicCapIcon } from "@heroicons/react/24/solid";
import { IoExitOutline } from "react-icons/io5";

const CustomDialogBlock = ({ title, content }) => {
  return (
    <>
      <Dialog.Title
        as="h3"
        className="text-base mt-2 font-semibold leading-6 text-primaryBlue"
      >
        {title}
      </Dialog.Title>
      <div className="mt-2">
        <p
          className="text-sm text-primaryBlue/70"
          dangerouslySetInnerHTML={{ __html: content }}
        />
      </div>
    </>
  );
};

export default function ModalExtend({ open, setOpen, programInfo }) {
  const cancelButtonRef = useRef(null);

  return (
    <Transition.Root show={open} as={Fragment}>
      <Dialog
        as="div"
        className="relative z-10"
        initialFocus={cancelButtonRef}
        onClose={setOpen}
      >
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-black/60 transition-opacity" />
        </Transition.Child>

        <div className="fixed inset-0 z-10 w-screen overflow-y-auto">
          <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
              enterTo="opacity-100 translate-y-0 sm:scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 translate-y-0 sm:scale-100"
              leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            >
              <Dialog.Panel className="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all lg:my-8 lg:w-full lg:max-w-6xl">
                <button
                  type="button"
                  className="text-red-500 w-full text-right mt-1"
                >
                  <XMarkIcon
                    className="h-7 w-7 lg:w-8 lg:h-8 mr-1 inline-flex"
                    onClick={() => setOpen(false)}
                    ref={cancelButtonRef}
                  />
                </button>
                <div className="bg-white px-4 -mt-6 pb-4 sm:p-6 sm:pb-4">
                  <div className="sm:flex sm:items-start">
                    <div className="mt-3 text-left sm:ml-4 sm:mt-0">
                      <Dialog.Title
                        as="h3"
                        className="text-lg font-bold leading-6 text-primaryBlue"
                      >
                        {programInfo && programInfo.titleProgram}
                      </Dialog.Title>
                      <div className="mt-2">
                        <p className="text-sm text-primaryBlue/70">
                          {programInfo && programInfo.descriptionProgram}
                        </p>
                      </div>
                      <CustomDialogBlock
                        title="Registros del programa"
                        content={programInfo && programInfo.recordsProgram}
                      />
                      <CustomDialogBlock
                        title="Duración del programa"
                        content={programInfo && programInfo.timeProgram}
                      />
                      <CustomDialogBlock
                        title="Objetivos del programa"
                        content={programInfo && programInfo.objectiveProgram}
                      />
                      <CustomDialogBlock
                        title="Perfil del egresado"
                        content={programInfo && programInfo.graduateProfile}
                      />
                      <CustomDialogBlock
                        title="Certificado de aptitud ocupacional a expedir"
                        content={programInfo && programInfo.cetification}
                      />
                      <CustomDialogBlock
                        title="Perfil ocupacional"
                        content={programInfo && programInfo.occupationalProfile}
                      />
                      <div className="text-sm mt-2">
                        <h3 className="text-base font-semibold text-primaryBlue">
                          Plan de estudio
                        </h3>
                        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-2 mx-auto mt-2">
                          {programInfo &&
                            programInfo.studyPlan.map((semester, index) => (
                              <div
                                key={index}
                                className="border rounded-md rounded-b-none border-primaryBlue"
                              >
                                <h4 className="font-semibold pl-1 text-primaryBlue">
                                  {semester.semestrer}
                                </h4>
                                <ul>
                                  {semester.subject.map((subject, subIndex) => (
                                    <li
                                      className="h-[52px] max-h-[60px] text-xs px-1 flex items-center ring-1 ring-opacity-60  ring-primaryBlue overflow-y-auto text-primaryBlue"
                                      key={subIndex}
                                    >
                                      <span>
                                        <AcademicCapIcon className="inline-flex h-3 w-3 mr-1" />
                                      </span>
                                      {subject}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            ))}
                        </div>
                      </div>
                      <CustomDialogBlock
                        title="Requisitos de ingreso"
                        content={programInfo && programInfo.loginRequirements}
                      />
                    </div>
                  </div>
                </div>
                <div className="bg-white px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6">
                  <button
                    type="button"
                    className="mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-red-500 shadow-sm ring-1 ring-inset ring-red-300 hover:bg-gray-50 sm:mt-0 sm:w-auto"
                    onClick={() => setOpen(false)}
                    ref={cancelButtonRef}
                  >
                    Salir <IoExitOutline className="h-5 w-5 ml-2 inline-flex" />
                  </button>
                </div>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition.Root>
  );
}