export const metadata = {
  title: "Políticas de Privacidad"
}

import PrivatePolicies from "@/components/private_policies";

export default function page_polices() {
  return (
    <div>
      <PrivatePolicies />
    </div>
  );
}
